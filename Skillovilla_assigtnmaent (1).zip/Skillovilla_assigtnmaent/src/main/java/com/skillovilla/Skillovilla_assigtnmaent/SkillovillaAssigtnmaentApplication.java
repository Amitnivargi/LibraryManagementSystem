package com.skillovilla.Skillovilla_assigtnmaent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SkillovillaAssigtnmaentApplication {

	public static void main(String[] args) {
		SpringApplication.run(SkillovillaAssigtnmaentApplication.class, args);
	}

}
