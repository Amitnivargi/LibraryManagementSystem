package com.skillovilla.Skillovilla_assigtnmaent;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SkillovillaAssigtnmaentApplicationTests {

	@Test
	void contextLoads() {
	}

}
